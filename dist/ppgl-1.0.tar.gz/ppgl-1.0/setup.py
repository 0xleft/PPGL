from setuptools import setup

setup(
    name='ppgl',
    version='1.0',
    description='A tkinter library that juts works',
    author='0xleft',
    author_email='your@email.com',
    url='https://github.com/0xleft/ppgl',
    packages=['ppgl'],
)